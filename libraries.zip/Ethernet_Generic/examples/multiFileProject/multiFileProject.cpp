/****************************************************************************************************************************
  multiFileProject.cpp
  Ethernet_Generic is a library for the W5x00 Ethernet shields trying to merge the good features of
  previous Ethernet libraries

  Built by Khoi Hoang https://github.com/khoih-prog/Ethernet_Generic
*****************************************************************************************************************************/

// To demo how to include files in multi-file Projects

#include "multiFileProject.h"
